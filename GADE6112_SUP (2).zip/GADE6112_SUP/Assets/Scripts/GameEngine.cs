﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEngine : MonoBehaviour
{
    //[SerializeField] GameObject[] options = new GameObject[2];
    //[SerializeField] static int MIN_X = -10, MAX_X = 10, MIN_Z = -10, MAX_Z = 10, UNITS = 6;

    //// Start is called before the first frame update
    //void Start()
    //{
    //    for (int i = 0; i < UNITS; i++)
    //    {
    //        CreateUnit();
    //    }
    //}

    //void CreateUnit()
    //{
    //    GameObject unit = Instantiate(options[Random.Range(0, 2)]);
    //    unit.transform.position = new Vector3(Random.Range(MIN_X, MAX_X), 0, Random.Range(MIN_Z, MAX_Z));
    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}

    //public Transform[] spawnLacations;
    //public GameObject[] whatToSpawnPrefab;
    //public GameObject[] whatToSpawnClone;

    //void Start()
    //{
    //    spawn();
    //}

    //void spawn()
    //{
    //    whatToSpawnClone[0] = Instantiate(whatToSpawnPrefab[0], spawnLacations[0].transform.position, Quaternion.Euler(0, 0, 0)) as GameObject;
    //    whatToSpawnClone[1] = Instantiate(whatToSpawnPrefab[1], spawnLacations[1].transform.position, Quaternion.Euler(0, 0, 0)) as GameObject;
    //    //whatToSpawnClone[2] = Instantiate(whatToSpawnPrefab[2], spawnLacations[2].transform.position, Quaternion.Euler(0, 0, 0)) as GameObject;
    //}

    //public GameObject spawner;
    //public bool stopSpawning = false;
    //public float spawnTime;
    //public float spawnDelay;

    //void Start()
    //{
    //    InvokeRepeating("SpawnObject", spawnTime, spawnDelay);
    //}

    //public void SpawnObject()
    //{
    //    Instantiate(spawner, transform.position, transform.rotation);
    //    if (stopSpawning)
    //    {
    //        CancelInvoke("SpawnObject");
    //    }
    //}
}
